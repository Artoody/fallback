// keyManager.js
// مسئول نگهداری لیست API key ها، وضعیت هرکدوم، و انتخاب کلید بعدی برای استفاده

const COOLDOWN_MS = parseInt(process.env.KEY_COOLDOWN_MS || "60000", 10);

class KeyManager {
  constructor(keys) {
    if (!keys || keys.length === 0) {
      throw new Error("هیچ API keyـی تعریف نشده. مقدار GEMINI_API_KEYS رو در .env چک کن.");
    }
    // هر کلید یه آبجکت وضعیت داره: خودِ کلید، زمانی که تا اون موقع نباید استفاده بشه (بخاطر rate limit)، و شمارنده خطا
    this.keys = keys.map((key, idx) => ({
      key,
      index: idx,
      blockedUntil: 0, // اگه Date.now() از این کمتر باشه یعنی هنوز تو cooldown هست
      failCount: 0,
      lastUsed: 0,
    }));
  }

  // لیست کلیدهایی که الان قابل استفاده‌ان (تو cooldown نیستن)، به ترتیب اولویت و نوبت در صف
  getAvailableOrder() {
    const now = Date.now();
    // اول کلیدهایی که در cooldown نیستن، بعد بقیه (شاید همه‌شون cooldown باشن، بازم امتحان می‌کنیم)
    const free = this.keys.filter((k) => k.blockedUntil <= now);
    const blocked = this.keys.filter((k) => k.blockedUntil > now);
    return [...free, ...blocked];
  }

  markSuccess(keyObj) {
    keyObj.failCount = 0;
    keyObj.blockedUntil = 0;
    keyObj.lastUsed = Date.now();
    
    // انتقال کلید موفق به انتهای صف برای توزیع متعادل بار (Round-Robin)
    const idx = this.keys.indexOf(keyObj);
    if (idx !== -1) {
      this.keys.splice(idx, 1);
      this.keys.push(keyObj);
    }
  }

  markRateLimited(keyObj) {
    keyObj.failCount += 1;
    keyObj.blockedUntil = Date.now() + COOLDOWN_MS;
    
    // انتقال کلید ناموفق به انتهای صف تا بلافاصله دوباره تست نشود
    const idx = this.keys.indexOf(keyObj);
    if (idx !== -1) {
      this.keys.splice(idx, 1);
      this.keys.push(keyObj);
    }
  }

  status() {
    const now = Date.now();
    return this.keys.map((k) => ({
      index: k.index,
      keyPreview: k.key.slice(0, 6) + "...",
      blocked: k.blockedUntil > now,
      blockedForMs: Math.max(0, k.blockedUntil - now),
      failCount: k.failCount,
    }));
  }

  /** همگام‌سازی لیست کلیدها با store (بدون از دست دادن وضعیت cooldown کلیدهای موجود) */
  syncKeys(newKeys) {
    const unique = [...new Set((newKeys || []).map((k) => String(k).trim()).filter(Boolean))];
    if (unique.length === 0) {
      throw new Error("حداقل یک کلید Gemini لازم است.");
    }
    const existingByKey = new Map(this.keys.map((k) => [k.key, k]));
    this.keys = unique.map((key, idx) => {
      const prev = existingByKey.get(key);
      if (prev) {
        return { ...prev, index: idx, key };
      }
      return {
        key,
        index: idx,
        blockedUntil: 0,
        failCount: 0,
        lastUsed: 0,
      };
    });
  }

  addKey(key) {
    const k = String(key).trim();
    if (!k) throw new Error("کلید خالی است.");
    if (this.keys.some((x) => x.key === k)) throw new Error("این کلید از قبل وجود دارد.");
    this.keys.push({
      key: k,
      index: this.keys.length,
      blockedUntil: 0,
      failCount: 0,
      lastUsed: 0,
    });
  }

  removeKeyAt(index) {
    if (index < 0 || index >= this.keys.length) throw new Error("ایندکس نامعتبر است.");
    if (this.keys.length <= 1) throw new Error("حداقل یک کلید باید باقی بماند.");
    this.keys.splice(index, 1);
    this.keys.forEach((k, i) => {
      k.index = i;
    });
  }
}

export default KeyManager;
