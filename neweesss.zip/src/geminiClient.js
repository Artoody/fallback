// geminiClient.js
// فراخوانی Gemini دقیقاً با همان فرمت رسمی Google:
// POST /v1beta/models/{model}:{method}
// Headers: Content-Type: application/json + x-goog-api-key: <GEMINI_KEY>
// Body: همان JSON کلاینت

import fetch from "node-fetch";

const GOOGLE_BASE_URL = process.env.GOOGLE_BASE_URL || "https://generativelanguage.googleapis.com";

const RETRYABLE_STATUS_CODES = new Set([429, 500, 503]);

function isRetryableStatus(status) {
  return RETRYABLE_STATUS_CODES.has(status);
}

function isInvalidApiKeyError(status, errText = "") {
  if (status === 401 || status === 403) return true;
  const text = String(errText);
  return (
    /API_KEY_INVALID/i.test(text) ||
    /API key not valid/i.test(text) ||
    /API_KEY_SERVICE_BLOCKED/i.test(text) ||
    /PERMISSION_DENIED/i.test(text) ||
    /API key expired/i.test(text)
  );
}

function isClientRequestError(status, errText = "") {
  if (status !== 400) return false;
  if (isInvalidApiKeyError(status, errText)) return false;
  return true;
}

/** ساخت URL مثل گوگل — بدون گذاشتن key داخل query */
function buildUrl(path, query = {}) {
  const url = new URL(GOOGLE_BASE_URL + path);
  for (const [k, v] of Object.entries(query || {})) {
    // هرگز key کلاینت/پروکسی را به گوگل نفرست
    if (!k || k === "key" || k.toLowerCase() === "key") continue;
    if (v === undefined || v === null || v === "") continue;
    const value = Array.isArray(v) ? v[0] : v;
    url.searchParams.set(k, String(value));
  }
  return url.toString();
}

/** هدرها دقیقاً مثل مستندات رسمی Gemini */
function buildGoogleHeaders(apiKey) {
  return {
    "Content-Type": "application/json",
    "x-goog-api-key": apiKey,
  };
}

export async function callGeminiNonStream({ keyManager, path, body, query = {} }) {
  const orderedKeys = keyManager.getAvailableOrder();
  let lastError = null;

  for (const keyObj of orderedKeys) {
    const url = buildUrl(path, query);
    try {
      const resp = await fetch(url, {
        method: "POST",
        headers: buildGoogleHeaders(keyObj.key),
        body: JSON.stringify(body ?? {}),
      });

      if (resp.ok) {
        const data = await resp.json();
        keyManager.markSuccess(keyObj);
        return { ok: true, status: resp.status, data, usedKeyIndex: keyObj.index };
      }

      const errText = await resp.text();
      lastError = { status: resp.status, body: errText, usedKeyIndex: keyObj.index };

      if (isInvalidApiKeyError(resp.status, errText)) {
        keyManager.markInvalid(keyObj);
        continue;
      }

      if (isRetryableStatus(resp.status)) {
        keyManager.markRateLimited(keyObj);
        continue;
      }

      if (isClientRequestError(resp.status, errText)) {
        return { ok: false, status: resp.status, error: errText, usedKeyIndex: keyObj.index };
      }

      keyManager.markRateLimited(keyObj);
      continue;
    } catch (networkErr) {
      lastError = { status: 0, body: networkErr.message, usedKeyIndex: keyObj.index };
      keyManager.markRateLimited(keyObj);
      continue;
    }
  }

  return {
    ok: false,
    status: lastError?.status || 429,
    error: lastError?.body || "تمام کلیدهای API با خطا مواجه شدند یا rate-limit خوردند.",
    allKeysExhausted: true,
  };
}

export async function callGeminiStream({ keyManager, path, body, query = {}, onChunk, onStart }) {
  const orderedKeys = keyManager.getAvailableOrder();
  let lastError = null;

  // گوگل برای SSE از alt=sse استفاده می‌کند
  const streamQuery = { ...query, alt: "sse" };

  for (const keyObj of orderedKeys) {
    const url = buildUrl(path, streamQuery);
    try {
      const resp = await fetch(url, {
        method: "POST",
        headers: buildGoogleHeaders(keyObj.key),
        body: JSON.stringify(body ?? {}),
      });

      if (!resp.ok) {
        const errText = await resp.text();
        lastError = { status: resp.status, body: errText, usedKeyIndex: keyObj.index };

        if (isInvalidApiKeyError(resp.status, errText)) {
          keyManager.markInvalid(keyObj);
          continue;
        }

        if (isRetryableStatus(resp.status)) {
          keyManager.markRateLimited(keyObj);
          continue;
        }

        if (isClientRequestError(resp.status, errText)) {
          return { ok: false, status: resp.status, error: errText, usedKeyIndex: keyObj.index };
        }

        keyManager.markRateLimited(keyObj);
        continue;
      }

      if (onStart) onStart(keyObj.index);
      keyManager.markSuccess(keyObj);

      for await (const chunk of resp.body) {
        onChunk(chunk);
      }

      return { ok: true, usedKeyIndex: keyObj.index };
    } catch (networkErr) {
      lastError = { status: 0, body: networkErr.message, usedKeyIndex: keyObj.index };
      keyManager.markRateLimited(keyObj);
      continue;
    }
  }

  return {
    ok: false,
    status: lastError?.status || 429,
    error: lastError?.body || "تمام کلیدهای API با خطا مواجه شدند یا rate-limit خوردند.",
    allKeysExhausted: true,
  };
}
