// geminiClient.js
// مسئول فراخوانی واقعی API گوگل جمینای، با retry/fallback بین کلیدها

import fetch from "node-fetch";

const GOOGLE_BASE_URL = process.env.GOOGLE_BASE_URL || "https://generativelanguage.googleapis.com";

// کدهایی که باید باعث رفتن سراغ کلید بعدی بشن
const RATE_LIMIT_STATUS_CODES = new Set([429]);
// این کدها هم گاهی به معنی مشکل موقتی سرور گوگله، می‌تونیم روشون هم fallback کنیم
const RETRYABLE_STATUS_CODES = new Set([429, 500, 503]);

/**
 * تشخیص اینکه آیا پاسخ خطا به خاطر quota/rate-limit یا مشکل موقتی سرور بوده یا نه
 */
function isRetryableStatus(status) {
  return RETRYABLE_STATUS_CODES.has(status);
}

/**
 * درخواست غیر استریم (generateContent) با fallback بین کلیدها
 * path مثلا: /v1beta/models/gemini-1.5-pro:generateContent
 */
export async function callGeminiNonStream({ keyManager, path, body, query = {} }) {
  const orderedKeys = keyManager.getAvailableOrder();
  let lastError = null;

  for (const keyObj of orderedKeys) {
    const url = buildUrl(path, keyObj.key, query);
    try {
      const resp = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (resp.ok) {
        const data = await resp.json();
        keyManager.markSuccess(keyObj);
        return { ok: true, status: resp.status, data, usedKeyIndex: keyObj.index };
      }

      const errText = await resp.text();
      lastError = { status: resp.status, body: errText, usedKeyIndex: keyObj.index };

      if (isRetryableStatus(resp.status)) {
        // یعنی این کلید احتمالا limit خورده یا سرور مشکل داره -> برو سراغ کلید بعدی
        keyManager.markRateLimited(keyObj);
        continue;
      } else {
        // خطای دیگه‌ای بوده (مثلا 400 - درخواست بد) که تعویض کلید کمکی نمی‌کنه
        return { ok: false, status: resp.status, error: errText, usedKeyIndex: keyObj.index };
      }
    } catch (networkErr) {
      // خطای شبکه‌ای، این کلید رو هم موقتا کنار بذاریم و بریم بعدی
      lastError = { status: 0, body: networkErr.message, usedKeyIndex: keyObj.index };
      keyManager.markRateLimited(keyObj);
      continue;
    }
  }

  // همه کلیدها fail شدن
  return {
    ok: false,
    status: lastError?.status || 429,
    error: lastError?.body || "تمام کلیدهای API با خطا مواجه شدند یا rate-limit خوردند.",
    allKeysExhausted: true,
  };
}

/**
 * درخواست استریم (streamGenerateContent) با fallback بین کلیدها
 * چون معمولا خطای rate-limit همون اول قبل از شروع stream برمی‌گرده،
 * فقط لازمه قبل از شروع pipe کردن، وضعیت response رو چک کنیم.
 * onChunk(chunkBuffer) برای هر تکه از استریم صدا زده میشه.
 */
export async function callGeminiStream({ keyManager, path, body, query = {}, onChunk, onStart }) {
  const orderedKeys = keyManager.getAvailableOrder();
  let lastError = null;

  const streamQuery = { ...query, alt: "sse" }; // گوگل با alt=sse فرمت SSE برمی‌گردونه

  for (const keyObj of orderedKeys) {
    const url = buildUrl(path, keyObj.key, streamQuery);
    try {
      const resp = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!resp.ok) {
        const errText = await resp.text();
        lastError = { status: resp.status, body: errText, usedKeyIndex: keyObj.index };
        if (isRetryableStatus(resp.status)) {
          keyManager.markRateLimited(keyObj);
          continue;
        } else {
          return { ok: false, status: resp.status, error: errText, usedKeyIndex: keyObj.index };
        }
      }

      // استریم با موفقیت شروع شد
      if (onStart) onStart(keyObj.index);
      keyManager.markSuccess(keyObj);

      for await (const chunk of resp.body) {
        onChunk(chunk);
      }

      return { ok: true, usedKeyIndex: keyObj.index };
    } catch (networkErr) {
      lastError = { status: 0, body: networkErr.message, usedKeyIndex: keyObj.index };
      keyManager.markRateLimited(keyObj);
      continue;
    }
  }

  return {
    ok: false,
    status: lastError?.status || 429,
    error: lastError?.body || "تمام کلیدهای API با خطا مواجه شدند یا rate-limit خوردند.",
    allKeysExhausted: true,
  };
}

function buildUrl(path, apiKey, query) {
  const url = new URL(GOOGLE_BASE_URL + path);
  url.searchParams.set("key", apiKey);
  for (const [k, v] of Object.entries(query)) {
    if (v !== undefined && v !== null) url.searchParams.set(k, v);
  }
  return url.toString();
}
