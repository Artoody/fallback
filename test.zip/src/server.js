// server.js
// این سرور دقیقا همون structure و path هایی که برای Gemini API استفاده می‌کنی رو ساپورت می‌کنه.
// کافیه به جای https://generativelanguage.googleapis.com آدرس همین سرور رو صدا بزنی
// (بدون نیاز به دادن key، چون خودش از بین چند کلید تعریف شده انتخاب می‌کنه)

import "dotenv/config";
import express from "express";
import KeyManager from "./keyManager.js";
import { callGeminiNonStream, callGeminiStream } from "./geminiClient.js";

const app = express();
app.use(express.json({ limit: "50mb" }));

const rawKeys = (process.env.GEMINI_API_KEYS || "")
  .split(",")
  .map((k) => k.trim())
  .filter(Boolean);

const keyManager = new KeyManager(rawKeys);

console.log(`[gemini-fallback-proxy] ${rawKeys.length} کلید API بارگذاری شد.`);

// ----------------------------------------------------------------
// احراز هویت: فقط کسی که PROXY_API_KEY درست رو بفرسته اجازه دسترسی داره
// ----------------------------------------------------------------
const PROXY_API_KEY = process.env.PROXY_API_KEY;

if (!PROXY_API_KEY || PROXY_API_KEY === "CHANGE_ME_TO_A_LONG_RANDOM_SECRET") {
  console.warn(
    "[gemini-fallback-proxy] هشدار: PROXY_API_KEY تنظیم نشده یا مقدار پیش‌فرضه! " +
      "این یعنی سرورت بدون هیچ محافظتی در دسترس همه‌ست. حتما یه مقدار امن تو .env بذار."
  );
}

function requireAuth(req, res, next) {
  // اگه اصلا کلیدی تنظیم نشده باشه، برای جلوگیری از دسترسی آزاد همه، درخواست رو رد می‌کنیم
  if (!PROXY_API_KEY) {
    return res.status(500).json({ error: "PROXY_API_KEY روی سرور تنظیم نشده." });
  }

  // ابزارهایی مثل Cline دقیقا مثل خود گوگل عمل می‌کنن و کلید رو یا تو هدر x-goog-api-key
  // یا تو query param به اسم key می‌فرستن. ما هر سه حالت رو قبول می‌کنیم تا نیازی به
  // تغییر تنظیمات کلاینت نباشه:
  const googHeaderKey = req.get("x-goog-api-key");
  const customHeaderKey = req.get("x-api-key");
  const authHeader = req.get("authorization"); // "Bearer xxxx"
  const bearerKey = authHeader && authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  const queryKey = req.query.key;

  const providedKey = googHeaderKey || customHeaderKey || bearerKey || queryKey;

  if (!providedKey || providedKey !== PROXY_API_KEY) {
    return res.status(401).json({ error: { message: "دسترسی غیرمجاز. کلید API معتبر ارسال نشده." } });
  }

  next();
}

// این مسیر عمومیه و نیازی به auth نداره (فقط برای چک سلامت سرور)
app.get("/", (req, res) => {
  res.json({ status: "ok", message: "Gemini fallback proxy در حال اجراست." });
});

// از این به بعد همه مسیرها نیاز به auth دارن
app.use(requireAuth);

// ----------------------------------------------------------------
// مسیر non-stream: مثلا POST /v1beta/models/gemini-1.5-pro:generateContent
// ----------------------------------------------------------------
app.post("/v1beta/models/:modelAndMethod", async (req, res) => {
  const { modelAndMethod } = req.params;

  // modelAndMethod چیزی مثل "gemini-1.5-pro:generateContent" یا "gemini-1.5-pro:streamGenerateContent" هست
  const [model, method] = modelAndMethod.split(":");

  if (!method) {
    return res.status(400).json({ error: "فرمت مسیر باید model:method باشه، مثلا gemini-1.5-pro:generateContent" });
  }

  const path = `/v1beta/models/${modelAndMethod}`;
  const query = { ...req.query };
  delete query.key; // اگه خودت هم key فرستادی نادیده می‌گیریم چون خودمون کلید انتخاب می‌کنیم

  if (method === "streamGenerateContent") {
    // ------------ حالت استریم ------------
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const result = await callGeminiStream({
      keyManager,
      path,
      body: req.body,
      query,
      onStart: (keyIndex) => {
        console.log(`[stream] شروع با کلید شماره ${keyIndex}`);
      },
      onChunk: (chunk) => {
        res.write(chunk);
      },
    });

    if (!result.ok) {
      // اگه هنوز چیزی برای کلاینت نفرستادیم، می‌تونیم خطای JSON عادی بفرستیم
      if (!res.headersSent) {
        res.status(result.status || 429).json({
          error: {
            message: result.error,
            allKeysExhausted: result.allKeysExhausted || false,
          },
        });
      } else {
        res.end();
      }
      return;
    }

    res.end();
    return;
  }

  // ------------ حالت غیر استریم (generateContent, embedContent, countTokens و ...) ------------
  const result = await callGeminiNonStream({
    keyManager,
    path,
    body: req.body,
    query,
  });

  if (!result.ok) {
    return res.status(result.status || 429).json({
      error: {
        message: result.error,
        allKeysExhausted: result.allKeysExhausted || false,
      },
    });
  }

  return res.status(result.status).json(result.data);
});

// ----------------------------------------------------------------
// مسیر دیباگ: وضعیت کلیدها رو نشون میده (بلاک شده/فعال/تعداد خطا)
// ----------------------------------------------------------------
app.get("/debug/keys-status", (req, res) => {
  res.json(keyManager.status());
});

const PORT = process.env.PORT || 8080;
// روی 0.0.0.0 گوش می‌دیم (نه فقط localhost)، چون پلتفرم‌های PaaS مثل Runflare
// از بیرون کانتینر به همین آدرس وصل میشن
app.listen(PORT, "0.0.0.0", () => {
  console.log(`[gemini-fallback-proxy] سرور روی پورت ${PORT} بالا اومد.`);
});
