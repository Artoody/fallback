// keyManager.js
// مسئول نگهداری لیست API key ها، وضعیت هرکدوم، و انتخاب کلید بعدی برای استفاده

const COOLDOWN_MS = parseInt(process.env.KEY_COOLDOWN_MS || "60000", 10);

class KeyManager {
  constructor(keys) {
    if (!keys || keys.length === 0) {
      throw new Error("هیچ API keyـی تعریف نشده. مقدار GEMINI_API_KEYS رو در .env چک کن.");
    }
    // هر کلید یه آبجکت وضعیت داره: خودِ کلید، زمانی که تا اون موقع نباید استفاده بشه (بخاطر rate limit)، و شمارنده خطا
    this.keys = keys.map((key, idx) => ({
      key,
      index: idx,
      blockedUntil: 0, // اگه Date.now() از این کمتر باشه یعنی هنوز تو cooldown هست
      failCount: 0,
      lastUsed: 0,
    }));
    this.cursor = 0; // برای round-robin
  }

  // لیست کلیدهایی که الان قابل استفاده‌ان (تو cooldown نیستن)، به ترتیب round-robin از cursor فعلی
  getAvailableOrder() {
    const now = Date.now();
    const n = this.keys.length;
    const ordered = [];
    for (let i = 0; i < n; i++) {
      const idx = (this.cursor + i) % n;
      ordered.push(this.keys[idx]);
    }
    // اول کلیدهایی که در cooldown نیستن، بعد بقیه (شاید همه‌شون cooldown باشن، بازم امتحان می‌کنیم)
    const free = ordered.filter((k) => k.blockedUntil <= now);
    const blocked = ordered.filter((k) => k.blockedUntil > now);
    return [...free, ...blocked];
  }

  markSuccess(keyObj) {
    keyObj.failCount = 0;
    keyObj.blockedUntil = 0;
    keyObj.lastUsed = Date.now();
    // cursor رو یکی جلو ببر تا دفعه بعد از کلید بعدی شروع بشه (توزیع بار بهتر)
    this.cursor = (keyObj.index + 1) % this.keys.length;
  }

  markRateLimited(keyObj) {
    keyObj.failCount += 1;
    keyObj.blockedUntil = Date.now() + COOLDOWN_MS;
    this.cursor = (keyObj.index + 1) % this.keys.length;
  }

  status() {
    const now = Date.now();
    return this.keys.map((k) => ({
      index: k.index,
      keyPreview: k.key.slice(0, 6) + "...",
      blocked: k.blockedUntil > now,
      blockedForMs: Math.max(0, k.blockedUntil - now),
      failCount: k.failCount,
    }));
  }
}

export default KeyManager;
